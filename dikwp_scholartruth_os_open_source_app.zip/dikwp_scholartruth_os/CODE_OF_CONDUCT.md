# Code of Conduct

Use this project to strengthen the scholarly record, not to harass individuals. Reports should be factual, evidence-bound, proportional and subject to human review.
