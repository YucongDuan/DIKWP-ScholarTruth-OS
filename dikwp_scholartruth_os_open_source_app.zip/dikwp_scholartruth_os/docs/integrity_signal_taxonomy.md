# Integrity Signal Taxonomy

## Signal families

- Identifier and metadata gaps
- Retraction / correction / expression-of-concern status
- Paper-mill and systematic manipulation signals
- Peer-review manipulation risk
- Authorship and contribution anomalies
- Image duplication / manipulation risk
- Statistical fragility and p-hacking signals
- Data availability and source custody gaps
- Ethics and clinical-trial registration gaps
- Citation ring and retracted-reference risk
- Textual overclaim / tortured phrase / template manuscript signals

## Principle

No single signal proves fraud. ScholarTruth aggregates signals into review priority while preserving residuals and right-to-reply.
