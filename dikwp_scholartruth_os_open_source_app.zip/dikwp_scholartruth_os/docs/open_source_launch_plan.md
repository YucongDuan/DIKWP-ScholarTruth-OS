# Open Source Launch Plan

1. Publish repository with synthetic demo only.
2. Avoid naming real papers or people in initial release.
3. Add README examples showing non-accusatory workflows.
4. Invite editors and research integrity experts to critique taxonomy.
5. Add adapters only after governance review.
6. Connect to TrustPassport for official registry and training.
