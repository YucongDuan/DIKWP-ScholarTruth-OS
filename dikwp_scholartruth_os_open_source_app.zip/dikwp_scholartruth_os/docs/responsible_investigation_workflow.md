# Responsible Academic Integrity Workflow

1. Register exact work and source identifiers.
2. Split concerns into categories and claim cards.
3. Collect public, verifiable evidence only.
4. Route concern to qualified review domain.
5. Request clarification without accusation.
6. Incorporate author/editor/institution response.
7. Escalate only with adequate source custody.
8. Prefer correction, expression of concern, data clarification, or metadata repair when misconduct is not established.
