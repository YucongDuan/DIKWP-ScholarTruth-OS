# GitHub Release Draft

DIKWP ScholarTruth OS v0.1.0 is an offline-first academic integrity triage and evidence ledger system. It helps convert research integrity concerns into structured evidence ledgers, signal matrices, claim cards, and responsible inquiry workflows.

This release includes a synthetic demo and intentionally avoids automated accusations or live scraping.
