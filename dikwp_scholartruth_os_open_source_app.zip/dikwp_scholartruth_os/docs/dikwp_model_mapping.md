# DIKWP Model Mapping

- D: metadata, figures, tables, statistics, raw data statements, citations, author records.
- I: relationships among claims, methods, data, sources, authors, journals, review process.
- K: research integrity norms, methods standards, publication ethics, evidence hierarchy.
- W: proportionality, due process, reputational harm, non-accusatory wording, qualified expertise.
- P: protect the scholarly record while minimizing wrongful accusation and harassment.
- R: source custody, review strength, borrowed reliability, residuals, kill/recovery conditions.
