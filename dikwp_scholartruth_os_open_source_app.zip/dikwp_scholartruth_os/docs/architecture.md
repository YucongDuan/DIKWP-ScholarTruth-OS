# Architecture

```text
Academic Work Manifest
  -> D/I/K/W/P/R Registration
  -> Signal Extractors
       identifier / metadata / authorship / image / statistics / data availability / ethics / trial / citation / peer review / textual overclaim
  -> Integrity Signal Matrix
  -> Claim Cards
  -> Evidence Ledger
  -> Responsible Correction Workflow
  -> Human Review / Editorial / Institutional Escalation
```

The system is intentionally offline-first. Connectors to Crossref, PubMed, Retraction Watch, PubPeer, ORCID, and image forensics tools should be separate adapters, not part of the default offline core.
