# Governance Boundary

ScholarTruth OS must not be used for automated public accusations. It must not harass authors, scrape private systems, expose private personal data, or bypass institutional procedures. It is a triage and evidence organization system.

## Allowed

- Non-accusatory internal review.
- Journal or institutional inquiry preparation.
- Evidence ledger construction.
- Claim-to-evidence support mapping.
- Correction workflow planning.

## Not allowed

- Automated public naming-and-shaming.
- Legal determinations.
- Doxxing or credential access.
- Fake evidence generation.
- Automated complaint submission without human review.
