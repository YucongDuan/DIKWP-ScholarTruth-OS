# Roadmap

- v0.1: Offline synthetic demo and signal matrix.
- v0.2: Crossref / Retraction Watch adapter.
- v0.3: PubPeer / post-publication review references.
- v0.4: Image-forensics adapter interface.
- v0.5: Discipline packs for biomedical, social science, engineering, humanities.
- v1.0: Institution deployment template and TrustPassport integration.
