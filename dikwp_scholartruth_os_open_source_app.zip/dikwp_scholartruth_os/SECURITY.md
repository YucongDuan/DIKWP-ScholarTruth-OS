# Security Policy

The offline core must not contain hidden telemetry, credential handling, browser automation, dynamic execution, or private-system access helpers. Report security issues privately to project maintainers.
