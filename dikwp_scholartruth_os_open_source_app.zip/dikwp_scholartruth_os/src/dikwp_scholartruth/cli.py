import argparse, json
from pathlib import Path
from .analyzer import ScholarTruthAnalyzer, write_outputs
from .static_audit import run_static_audit

def main():
    parser = argparse.ArgumentParser(prog="scholartruth")
    sub = parser.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("analyze")
    p.add_argument("case_json")
    p.add_argument("--policy", default=None)
    p.add_argument("--out", default="outputs/demo")
    a = sub.add_parser("static-audit")
    a.add_argument("path")
    a.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    args = parser.parse_args()
    if args.cmd == "analyze":
        case = json.loads(Path(args.case_json).read_text(encoding="utf-8"))
        policy = json.loads(Path(args.policy).read_text(encoding="utf-8")) if args.policy else None
        result = ScholarTruthAnalyzer(policy).analyze(case)
        write_outputs(result, args.out)
        print(json.dumps({"decision": result["decision"], "risk_score": result["integrity_risk_score"], "signals": result["signal_count"]}, ensure_ascii=False, indent=2))
    elif args.cmd == "static-audit":
        result = run_static_audit(args.path)
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
