def register_integrity_object(data, info=None, knowledge=None, wisdom=None, purpose=None, reliability=None):
    return {
        "D": data or {},
        "I": info or {},
        "K": knowledge or {},
        "W": wisdom or {},
        "P": purpose or {},
        "R": reliability or {},
    }
