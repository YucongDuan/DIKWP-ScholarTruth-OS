from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

@dataclass
class EvidenceItem:
    evidence_id: str
    source_type: str
    description: str
    supports: List[str] = field(default_factory=list)
    does_not_support: List[str] = field(default_factory=list)
    reliability: str = "Provisional"
    borrowed: bool = True

@dataclass
class IntegritySignal:
    signal_id: str
    category: str
    severity: str
    score: float
    description: str
    evidence_refs: List[str] = field(default_factory=list)
    action: str = "human_review"

@dataclass
class ClaimCard:
    claim_id: str
    claim: str
    support_level: str
    evidence_refs: List[str]
    residual: str
    kill_conditions: List[str]
    recovery: str

def to_dict(obj: Any) -> Dict[str, Any]:
    return asdict(obj)
