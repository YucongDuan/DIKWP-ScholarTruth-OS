# Report helpers are implemented in analyzer.py for the offline core.
