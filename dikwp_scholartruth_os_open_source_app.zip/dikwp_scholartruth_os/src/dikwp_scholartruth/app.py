def main():
    try:
        import streamlit as st
    except Exception:
        raise SystemExit("Install with: pip install -e .[app]")
    st.title("DIKWP ScholarTruth OS")
    st.write("Upload or paste a case JSON, then run offline integrity triage.")

if __name__ == "__main__":
    main()
