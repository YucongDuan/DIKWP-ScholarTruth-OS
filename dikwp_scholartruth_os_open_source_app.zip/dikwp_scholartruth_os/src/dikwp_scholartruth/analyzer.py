import json, csv, math, re, hashlib
from pathlib import Path
from typing import Dict, List, Any, Tuple
from .models import EvidenceItem, IntegritySignal, ClaimCard, to_dict
from .text_utils import lower_join, contains_any, simple_hash, tokenize

SUSPICIOUS_PHRASES = [
    "tortured phrase", "suspiciously generic", "ground-breaking", "100%", "guarantee",
    "universal cure", "no limitations", "perfect accuracy", "all diseases", "never fails",
    "paper mill", "template manuscript", "rapid acceptance", "guest editor guarantee"
]
IMAGE_RISK_TERMS = ["duplicated image", "duplicated band", "western blot", "gel band", "splice", "contrast adjusted", "reused panel"]
DATA_RISK_TERMS = ["data unavailable", "available upon request", "lost data", "no raw data", "cannot share data", "confidential but no approval"]
STATS_RISK_PATTERNS = [r"p\s*[=<>]\s*0\.05\b", r"p\s*=\s*0\.049\b", r"p\s*=\s*0\.051\b"]
ETHICS_TERMS = ["human subjects", "patient", "animal", "clinical trial", "intervention", "biopsy", "informed consent"]

DESIGN_WEIGHTS = {
    "randomized_controlled_trial": 0.90,
    "systematic_review": 0.82,
    "meta_analysis": 0.80,
    "cohort": 0.70,
    "case_control": 0.62,
    "cross_sectional": 0.52,
    "case_series": 0.42,
    "preclinical": 0.36,
    "opinion": 0.22,
}

class ScholarTruthAnalyzer:
    def __init__(self, policy: Dict[str, Any] | None = None):
        self.policy = policy or {}

    def analyze(self, case: Dict[str, Any]) -> Dict[str, Any]:
        works = case.get("works", [])
        evidence: List[EvidenceItem] = []
        signals: List[IntegritySignal] = []
        claims: List[ClaimCard] = []
        author_rows = []
        ledgers = []

        for idx, work in enumerate(works, start=1):
            wid = work.get("work_id", f"W{idx}")
            ev_id = f"EV-{wid}-metadata"
            evidence.append(EvidenceItem(ev_id, "metadata", f"Metadata and manifest fields for {wid}", [wid], [], "Borrowed", True))
            work_text = lower_join([
                work.get("title", ""), work.get("abstract", ""), work.get("claims_text", ""),
                " ".join(work.get("notes", [])), " ".join(work.get("limitations", []))
            ])
            signals += self._identifier_signals(work, wid, ev_id)
            signals += self._metadata_signals(work, wid, ev_id)
            signals += self._authorship_signals(work, wid, ev_id, author_rows)
            signals += self._textual_signals(work, wid, work_text, ev_id)
            signals += self._data_stats_signals(work, wid, work_text, ev_id)
            signals += self._ethics_trial_signals(work, wid, work_text, ev_id)
            signals += self._citation_signals(work, wid, ev_id)
            signals += self._peer_review_signals(work, wid, ev_id)
            signals += self._image_signals(work, wid, ev_id)

            for cidx, c in enumerate(work.get("claims", []), start=1):
                support = self._claim_support_level(c, work)
                claims.append(ClaimCard(
                    claim_id=f"CL-{wid}-{cidx}",
                    claim=c.get("text", str(c)),
                    support_level=support[0],
                    evidence_refs=[ev_id] + support[1],
                    residual=support[2],
                    kill_conditions=support[3],
                    recovery="Request source data, independent replication, method clarification, and editorial/institutional review before public accusation."
                ))

            ledgers.append(self._dikwp_record(work, wid))

        risk_score = self._aggregate_risk(signals)
        decision = self._decision(risk_score, signals)
        category_counts = {}
        for s in signals:
            category_counts[s.category] = category_counts.get(s.category, 0) + 1

        return {
            "system": "DIKWP ScholarTruth OS",
            "version": "0.1.0",
            "case_id": case.get("case_id", "case-unknown"),
            "case_title": case.get("title", "Untitled academic integrity case"),
            "work_count": len(works),
            "integrity_risk_score": round(risk_score, 4),
            "decision": decision,
            "signal_count": len(signals),
            "signal_category_counts": category_counts,
            "evidence_ledger": [to_dict(x) for x in evidence],
            "signals": [to_dict(x) for x in signals],
            "claim_cards": [to_dict(x) for x in claims],
            "dikwp_ledger": ledgers,
            "author_network_rows": author_rows,
            "truth_reliability_gradient": self._gradient(risk_score, decision),
            "action_boundary": "Triage only. Do not make public accusations without human expert review, right-to-reply, and institutional or editorial process.",
            "kill_conditions": [
                "Use of the report as a final legal or academic misconduct determination.",
                "Publishing named allegations without source custody and human review.",
                "Using private data, doxxing, credential access, or harassment to collect evidence.",
                "Treating weak textual signals as proof of fabrication."
            ],
            "recovery_conditions": [
                "Convert findings to non-accusatory questions.",
                "Ask journal/editor/institution for records and raw data through proper channels.",
                "Downgrade unsupported claims to residuals.",
                "Add contradictory evidence and author response to the ledger."
            ]
        }

    def _identifier_signals(self, work, wid, ev_id):
        signals = []
        if not work.get("doi") and not work.get("pmid") and not work.get("preprint_id"):
            signals.append(IntegritySignal(f"SIG-{wid}-id-missing", "identifier_gap", "medium", 0.45,
                "No DOI, PMID, preprint ID, or durable identifier provided.", [ev_id], "human_review"))
        doi = str(work.get("doi", ""))
        if doi and not doi.startswith("10."):
            signals.append(IntegritySignal(f"SIG-{wid}-doi-pattern", "metadata_anomaly", "medium", 0.35,
                "DOI does not follow the usual '10.' prefix pattern; verify metadata manually.", [ev_id], "verify_identifier"))
        if work.get("retraction_status") in ["retracted", "expression_of_concern", "correction_required"]:
            severity = "high" if work.get("retraction_status") == "retracted" else "medium"
            signals.append(IntegritySignal(f"SIG-{wid}-retraction", "publication_record", severity, 0.85,
                f"Publication status is marked as {work.get('retraction_status')}; check Crossref/PubMed/publisher record.", [ev_id], "do_not_use_as_clean_evidence"))
        return signals

    def _metadata_signals(self, work, wid, ev_id):
        signals=[]
        if work.get("received_to_accepted_days") is not None and work.get("received_to_accepted_days") <= 7:
            signals.append(IntegritySignal(f"SIG-{wid}-rapid-accept", "publication_process", "medium", 0.35,
                "Very short received-to-accepted interval; may be legitimate but requires context for peer review integrity.", [ev_id], "editorial_review"))
        if work.get("journal_indexing_claim") and work.get("journal_indexing_claim") == "unclear":
            signals.append(IntegritySignal(f"SIG-{wid}-indexing", "journal_quality", "low", 0.20,
                "Journal indexing or scope claim is unclear.", [ev_id], "verify_journal"))
        if work.get("article_type") == "special_issue" and work.get("guest_editor_conflict"):
            signals.append(IntegritySignal(f"SIG-{wid}-guest-editor", "publication_process", "medium", 0.45,
                "Special issue / guest editor conflict signal present.", [ev_id], "editorial_review"))
        return signals

    def _authorship_signals(self, work, wid, ev_id, author_rows):
        signals=[]
        authors = work.get("authors", [])
        for a in authors:
            email = str(a.get("email", ""))
            row = {"work_id": wid, "author": a.get("name", ""), "orcid": a.get("orcid", ""), "affiliation": a.get("affiliation", ""), "email_domain": email.split("@")[-1] if "@" in email else ""}
            author_rows.append(row)
            if not a.get("orcid"):
                signals.append(IntegritySignal(f"SIG-{wid}-orcid-{simple_hash(a.get('name',''))}", "authorship_metadata", "low", 0.12,
                    f"Author {a.get('name','')} lacks ORCID in manifest; not misconduct but reduces disambiguation reliability.", [ev_id], "metadata_completion"))
            if email and any(email.endswith(x) for x in ["gmail.com", "qq.com", "163.com", "hotmail.com"]):
                signals.append(IntegritySignal(f"SIG-{wid}-email-{simple_hash(email)}", "authorship_metadata", "low", 0.10,
                    f"Author {a.get('name','')} uses personal email domain; verify only if other signals exist.", [ev_id], "metadata_context"))
        if len(authors) >= 8 and not work.get("contribution_statement"):
            signals.append(IntegritySignal(f"SIG-{wid}-contrib-missing", "authorship_metadata", "medium", 0.30,
                "Large author team but no contribution statement provided.", [ev_id], "request_contribution_statement"))
        return signals

    def _textual_signals(self, work, wid, text, ev_id):
        signals=[]
        hits = contains_any(text, SUSPICIOUS_PHRASES)
        if hits:
            signals.append(IntegritySignal(f"SIG-{wid}-text-overclaim", "textual_overclaim_or_template", "medium", min(0.15*len(hits)+0.2,0.8),
                "Text contains overclaim/template-risk terms: " + ", ".join(hits[:8]), [ev_id], "claim_downgrade"))
        if len(set(tokenize(work.get("abstract", "")))) < 20 and len(work.get("abstract", "")) > 200:
            signals.append(IntegritySignal(f"SIG-{wid}-low-lexical", "textual_anomaly", "low", 0.18,
                "Low lexical diversity in abstract; can indicate template text or boilerplate, but is not proof.", [ev_id], "manual_reading"))
        return signals

    def _data_stats_signals(self, work, wid, text, ev_id):
        signals=[]
        design = work.get("study_design", "").lower()
        n = work.get("sample_size")
        if design and design not in ["opinion", "review"] and (n is None or n == 0):
            signals.append(IntegritySignal(f"SIG-{wid}-sample-missing", "methods_gap", "medium", 0.42,
                "Empirical study lacks sample size in manifest.", [ev_id], "request_methods_detail"))
        if any(term in text for term in DATA_RISK_TERMS) or work.get("data_availability") in ["none", "upon_request_only", "lost"]:
            signals.append(IntegritySignal(f"SIG-{wid}-data-availability", "data_custody_gap", "medium", 0.40,
                "Data availability is weak or absent; request raw data / repository / reasoned restriction.", [ev_id], "request_data"))
        p_hits=[]
        for pat in STATS_RISK_PATTERNS:
            p_hits += re.findall(pat, text)
        if p_hits:
            signals.append(IntegritySignal(f"SIG-{wid}-pvalue-boundary", "statistical_fragility", "medium", 0.38,
                "P-value boundary signals found: " + ", ".join(p_hits[:6]), [ev_id], "statistical_review"))
        if work.get("effect_size") == "not_reported" and design in ["randomized_controlled_trial", "cohort", "case_control"]:
            signals.append(IntegritySignal(f"SIG-{wid}-effect-size", "statistical_reporting_gap", "low", 0.20,
                "Effect size not reported for a design where effect magnitude is important.", [ev_id], "request_effect_size"))
        return signals

    def _ethics_trial_signals(self, work, wid, text, ev_id):
        signals=[]
        if any(t in text for t in ETHICS_TERMS) or work.get("human_or_animal_subjects"):
            if not work.get("ethics_statement"):
                signals.append(IntegritySignal(f"SIG-{wid}-ethics", "ethics_gap", "high", 0.65,
                    "Human/animal/clinical signal present but ethics statement missing from manifest.", [ev_id], "ethics_review"))
        if "clinical trial" in text or work.get("clinical_trial"):
            if not work.get("trial_registration"):
                signals.append(IntegritySignal(f"SIG-{wid}-trial-registration", "trial_registration_gap", "high", 0.70,
                    "Clinical trial signal present but trial registration absent in manifest.", [ev_id], "trial_registry_review"))
        return signals

    def _citation_signals(self, work, wid, ev_id):
        signals=[]
        refs = work.get("references", [])
        if len(refs) > 0:
            self_refs = sum(1 for r in refs if r.get("self_citation"))
            if self_refs/len(refs) > 0.45 and len(refs) >= 10:
                signals.append(IntegritySignal(f"SIG-{wid}-self-citation", "citation_pattern", "medium", 0.35,
                    f"High self-citation ratio {self_refs}/{len(refs)}; verify field norm and citation ring risk.", [ev_id], "citation_review"))
            retracted_refs = [r for r in refs if r.get("status") == "retracted"]
            if retracted_refs:
                signals.append(IntegritySignal(f"SIG-{wid}-retracted-refs", "citation_integrity", "high", 0.70,
                    f"References include {len(retracted_refs)} retracted items; verify whether they are cited as retracted.", [ev_id], "reference_correction"))
        return signals

    def _peer_review_signals(self, work, wid, ev_id):
        signals=[]
        pr = work.get("peer_review", {})
        suggested = pr.get("suggested_reviewers", [])
        if suggested:
            personal = [x for x in suggested if any(str(x.get("email","")).endswith(d) for d in ["gmail.com","hotmail.com","qq.com","163.com"])]
            if len(personal) >= max(1, len(suggested)//2):
                signals.append(IntegritySignal(f"SIG-{wid}-reviewer-email", "peer_review_manipulation_risk", "high", 0.68,
                    "Suggested reviewer list heavily uses personal email domains; verify reviewer identity and independence.", [ev_id], "editorial_review"))
        if pr.get("reviewer_identity_issue"):
            signals.append(IntegritySignal(f"SIG-{wid}-reviewer-identity", "peer_review_manipulation_risk", "high", 0.75,
                "Manifest includes reviewer identity concern.", [ev_id], "editorial_review"))
        return signals

    def _image_signals(self, work, wid, ev_id):
        signals=[]
        imgs = work.get("image_notes", [])
        text = lower_join(imgs)
        hits = contains_any(text, IMAGE_RISK_TERMS)
        if hits:
            signals.append(IntegritySignal(f"SIG-{wid}-image-risk", "image_integrity", "high", min(0.25*len(hits)+0.35, 0.9),
                "Image integrity signal present: " + ", ".join(hits), [ev_id], "image_forensic_review"))
        image_hashes = work.get("image_hashes", [])
        if image_hashes and len(image_hashes) != len(set(image_hashes)):
            signals.append(IntegritySignal(f"SIG-{wid}-image-duplicate-hash", "image_integrity", "high", 0.78,
                "Duplicate image hashes appear in manifest; verify whether reuse is legitimate.", [ev_id], "image_forensic_review"))
        return signals

    def _claim_support_level(self, c, work) -> Tuple[str, List[str], str, List[str]]:
        claim_text = str(c.get("text", c)).lower()
        evidence_refs = c.get("evidence_refs", [])
        design = work.get("study_design", "").lower()
        design_score = DESIGN_WEIGHTS.get(design, 0.35)
        overclaim = any(t in claim_text for t in ["prove", "guarantee", "universal", "all patients", "no limitation", "cure"])
        if overclaim and design_score < 0.75:
            return ("Blocked / overclaim", evidence_refs, "Claim exceeds design strength; downgrade wording.", ["Independent replication contradicts claim", "Raw data unavailable", "Effect disappears after correction"])
        if not evidence_refs:
            return ("Review / evidence gap", [], "No claim-specific evidence reference supplied.", ["No source can be matched to claim", "Source does not support claimed scope"])
        if design_score >= 0.75:
            return ("Supported / design-aware", evidence_refs, "Still requires source-level verification and conflict check.", ["Retraction/correction found", "Major undisclosed bias", "Effect not reproducible"])
        return ("Provisional / context support", evidence_refs, "Support is limited by study design or incomplete method details.", ["Method mismatch", "Sample size invalid", "Contradictory higher-level evidence"])

    def _dikwp_record(self, work, wid):
        return {
            "work_id": wid,
            "D": {"metadata": {k: work.get(k) for k in ["title","doi","pmid","year","journal","study_design","sample_size"]}},
            "I": {"relations": ["authors-work", "claims-evidence", "methods-data", "citations-sources"], "risk_context": work.get("integrity_context", "unknown")},
            "K": {"method_norms": ["identifier verification", "data availability", "ethics review", "statistical review", "citation integrity", "image forensics"]},
            "W": {"boundary": "Non-accusatory integrity triage; protect scholarly record and due process."},
            "P": {"goal": "identify review-worthy integrity risks without public accusation", "feedback": "editorial/institutional review updates ledger"},
            "R": {"reliability": "Borrowed + Provisional", "residual": "Signals are not proof; require human review and external custody."}
        }

    def _aggregate_risk(self, signals: List[IntegritySignal]) -> float:
        if not signals:
            return 0.0
        # No single indicator should dominate completely; combine max and mean.
        scores = [max(0.0, min(1.0, s.score)) for s in signals]
        severity_bonus = sum(0.05 for s in signals if s.severity == "high")
        return min(1.0, 0.55*max(scores) + 0.35*(sum(scores)/len(scores)) + min(severity_bonus,0.25))

    def _decision(self, score: float, signals: List[IntegritySignal]) -> str:
        high = sum(1 for s in signals if s.severity == "high")
        if score >= 0.75 or high >= 4:
            return "investigation_packet_required"
        if score >= 0.50 or high >= 2:
            return "editorial_or_institutional_review_required"
        if score >= 0.30:
            return "manual_review_recommended"
        return "routine_metadata_completion"

    def _gradient(self, score, decision):
        return {
            "local_truth": "Signals detected in provided manifest and sample text.",
            "structural_truth": "Multiple independent categories increase review priority; no single signal proves fraud.",
            "operational_truth": decision,
            "ultimate_claim": "Blocked: system cannot declare misconduct; only authorized human processes can adjudicate.",
            "reliability": "Supported / RunProof for demo; Borrowed for any external metadata; Provisional for integrity inference."
        }


def write_outputs(result: Dict[str, Any], outdir: str | Path):
    out = Path(outdir); out.mkdir(parents=True, exist_ok=True)
    (out/"scholartruth_report.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    with open(out/"integrity_signal_matrix.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["signal_id","category","severity","score","description","action","evidence_refs"])
        w.writeheader()
        for s in result["signals"]:
            row = dict(s); row["evidence_refs"] = ";".join(row.get("evidence_refs", [])); w.writerow(row)
    with open(out/"claim_cards.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["claim_id","claim","support_level","evidence_refs","residual","kill_conditions","recovery"])
        w.writeheader()
        for c in result["claim_cards"]:
            row = dict(c); row["evidence_refs"]=";".join(row.get("evidence_refs",[])); row["kill_conditions"]=";".join(row.get("kill_conditions",[])); w.writerow(row)
    (out/"claim_cards.json").write_text(json.dumps(result["claim_cards"], ensure_ascii=False, indent=2), encoding="utf-8")
    (out/"evidence_ledger.json").write_text(json.dumps(result["evidence_ledger"], ensure_ascii=False, indent=2), encoding="utf-8")
    (out/"dikwp_integrity_ledger.json").write_text(json.dumps(result["dikwp_ledger"], ensure_ascii=False, indent=2), encoding="utf-8")
    with open(out/"author_network_review.csv", "w", encoding="utf-8", newline="") as f:
        fields=["work_id","author","orcid","affiliation","email_domain"]
        w=csv.DictWriter(f, fieldnames=fields); w.writeheader()
        for r in result["author_network_rows"]: w.writerow(r)
    (out/"correction_workflow.md").write_text(make_workflow(result), encoding="utf-8")
    (out/"responsible_inquiry_letter.md").write_text(make_letter(result), encoding="utf-8")
    (out/"platform_journal_checklist.md").write_text(make_checklist(result), encoding="utf-8")


def make_workflow(result):
    return f"""# DIKWP ScholarTruth Correction Workflow\n\nCase: {result['case_id']}\nDecision: {result['decision']}\nRisk score: {result['integrity_risk_score']}\n\n## Step 1: Non-accusatory triage\nRecord every concern as a signal, not a verdict.\n\n## Step 2: Source custody\nAttach DOI/PMID/publisher pages, repository links, image panels, raw data requests and author responses.\n\n## Step 3: Category routing\n- Image concerns -> independent image forensic review.\n- Statistics concerns -> statistician review.\n- Peer review manipulation concerns -> journal/editorial office review.\n- Ethics/trial concerns -> IRB/registry verification.\n- Citation/retraction concerns -> reference correction.\n\n## Step 4: Right to reply\nSend questions that identify exact evidence, not public accusations.\n\n## Step 5: Escalation\nEscalate only if source custody and human review support the concern.\n\n## Kill conditions\n- Evidence does not support the alleged issue.\n- Legitimate explanation is provided and verified.\n- Concern relies on private or illegally obtained information.\n\n## Recovery\nDowngrade to residual, correction request, or metadata completion if the signal is not proof.\n"""

def make_letter(result):
    top = sorted(result["signals"], key=lambda x: x["score"], reverse=True)[:8]
    items = "\n".join([f"- {s['category']}: {s['description']}" for s in top])
    return f"""# Responsible Inquiry Letter Draft\n\nSubject: Request for clarification regarding research record {result['case_id']}\n\nDear Editor / Research Integrity Officer,\n\nI am writing to request clarification regarding several research-integrity signals identified during a non-accusatory review. This message is not a misconduct allegation. It is a request for verification and source-custody clarification.\n\nThe main review-worthy signals are:\n\n{items}\n\nCould you please advise whether the relevant source data, peer-review records, ethics approvals, image originals, trial registrations, or correction/retraction metadata are available for proper review?\n\nSincerely,\n[Name]\n\nBoundary: Please do not publish this draft as an accusation. Use it only as a controlled inquiry through appropriate channels.\n"""

def make_checklist(result):
    return """# Journal / Platform / Institution Checklist\n\n- [ ] Is the work identified by DOI, PMID, preprint ID, or publisher page?\n- [ ] Are all allegations rewritten as exact evidence-bound questions?\n- [ ] Is the image/statistical/ethics/citation concern routed to a qualified reviewer?\n- [ ] Has the author or responsible office been given a right to reply?\n- [ ] Are retraction/correction/expression-of-concern metadata checked?\n- [ ] Are private data, credentials, or unauthorized access excluded from evidence?\n- [ ] Does the draft avoid words such as fraud, fake, fabricated, or misconduct unless an authorized body has made such a finding?\n- [ ] Is there a recovery path if the concern is resolved?\n"""
