import ast, json
from pathlib import Path

FORBIDDEN_IMPORTS = {"requests", "urllib", "httpx", "aiohttp", "selenium", "playwright", "subprocess", "socket", "paramiko"}
FORBIDDEN_CALLS = {"eval", "exec", "compile", "__import__"}
FORBIDDEN_TEXT = ["steal_api_key", "password_capture_helper", "private_scraping_helper", "doxxing_helper", "auto_complaint_sender"]

def run_static_audit(path):
    base = Path(path)
    findings=[]
    for p in base.rglob("*.py"):
        text = p.read_text(encoding="utf-8")
        low = text.lower()
        if p.name == "static_audit.py":
            scan_text_terms = []
        else:
            scan_text_terms = FORBIDDEN_TEXT
        for term in scan_text_terms:
            if term in low:
                findings.append({"file": str(p), "type": "forbidden_text", "term": term})
        try:
            tree=ast.parse(text)
        except SyntaxError as e:
            findings.append({"file": str(p), "type": "syntax_error", "detail": str(e)})
            continue
        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                names=[]
                if isinstance(node, ast.Import):
                    names=[a.name.split('.')[0] for a in node.names]
                else:
                    names=[(node.module or '').split('.')[0]]
                for name in names:
                    if name in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(p), "type": "forbidden_import", "name": name})
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in FORBIDDEN_CALLS:
                findings.append({"file": str(p), "type": "forbidden_call", "name": node.func.id})
    return {"pass": len(findings)==0, "finding_count": len(findings), "findings": findings,
            "policy": "No network imports, subprocess, dynamic execution, credential capture, doxxing, hidden telemetry, or automated accusation/complaint helpers in the offline core."}
