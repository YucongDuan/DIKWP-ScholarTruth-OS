import re
from typing import Iterable, List

def lower_join(items: Iterable[str]) -> str:
    return " ".join(str(x).lower() for x in items if x is not None)

def contains_any(text: str, terms: Iterable[str]) -> List[str]:
    t = text.lower()
    return [term for term in terms if term.lower() in t]

def simple_hash(text: str) -> str:
    import hashlib
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]

def tokenize(text: str):
    return re.findall(r"[A-Za-z0-9_一-鿿]+", text.lower())
