# Contributing

Contributions should preserve the non-accusatory research integrity boundary. Add tests for any new signal. Never add network scraping, credential capture, hidden telemetry, or automated complaint submission to the offline core.
