import json
from pathlib import Path
from dikwp_scholartruth.analyzer import ScholarTruthAnalyzer
from dikwp_scholartruth.static_audit import run_static_audit

def test_demo_analysis_decision():
    case=json.loads(Path("examples/sample_integrity_case.json").read_text(encoding="utf-8"))
    result=ScholarTruthAnalyzer().analyze(case)
    assert result["work_count"] == 2
    assert result["integrity_risk_score"] > 0.5
    assert result["decision"] in ["editorial_or_institutional_review_required", "investigation_packet_required"]

def test_claim_cards_exist():
    case=json.loads(Path("examples/sample_integrity_case.json").read_text(encoding="utf-8"))
    result=ScholarTruthAnalyzer().analyze(case)
    assert len(result["claim_cards"]) >= 2
    assert any("overclaim" in c["support_level"].lower() for c in result["claim_cards"])

def test_static_audit_passes():
    result=run_static_audit("src")
    assert result["pass"] is True
