# DIKWP ScholarTruth Correction Workflow

Case: scholartruth-demo-001
Decision: investigation_packet_required
Risk score: 0.9207

## Step 1: Non-accusatory triage
Record every concern as a signal, not a verdict.

## Step 2: Source custody
Attach DOI/PMID/publisher pages, repository links, image panels, raw data requests and author responses.

## Step 3: Category routing
- Image concerns -> independent image forensic review.
- Statistics concerns -> statistician review.
- Peer review manipulation concerns -> journal/editorial office review.
- Ethics/trial concerns -> IRB/registry verification.
- Citation/retraction concerns -> reference correction.

## Step 4: Right to reply
Send questions that identify exact evidence, not public accusations.

## Step 5: Escalation
Escalate only if source custody and human review support the concern.

## Kill conditions
- Evidence does not support the alleged issue.
- Legitimate explanation is provided and verified.
- Concern relies on private or illegally obtained information.

## Recovery
Downgrade to residual, correction request, or metadata completion if the signal is not proof.
