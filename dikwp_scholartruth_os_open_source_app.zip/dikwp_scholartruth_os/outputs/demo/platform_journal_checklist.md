# Journal / Platform / Institution Checklist

- [ ] Is the work identified by DOI, PMID, preprint ID, or publisher page?
- [ ] Are all allegations rewritten as exact evidence-bound questions?
- [ ] Is the image/statistical/ethics/citation concern routed to a qualified reviewer?
- [ ] Has the author or responsible office been given a right to reply?
- [ ] Are retraction/correction/expression-of-concern metadata checked?
- [ ] Are private data, credentials, or unauthorized access excluded from evidence?
- [ ] Does the draft avoid words such as fraud, fake, fabricated, or misconduct unless an authorized body has made such a finding?
- [ ] Is there a recovery path if the concern is resolved?
